package com.study.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.study.entity.Region;


public interface RegionService extends IService<Region> {
}
