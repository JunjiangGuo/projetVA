package com.study.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.study.entity.Admin;


public interface AdminService extends IService<Admin> {
}
