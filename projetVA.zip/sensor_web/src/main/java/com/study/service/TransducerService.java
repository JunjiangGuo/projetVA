package com.study.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.study.entity.Transducer;


public interface TransducerService extends IService<Transducer> {
}
