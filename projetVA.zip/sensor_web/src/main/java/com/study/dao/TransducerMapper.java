package com.study.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.study.entity.Transducer;

public interface TransducerMapper extends BaseMapper<Transducer> {
}
