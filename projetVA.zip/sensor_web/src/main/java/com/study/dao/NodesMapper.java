package com.study.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.study.entity.Nodes;

public interface NodesMapper extends BaseMapper<Nodes> {
}
