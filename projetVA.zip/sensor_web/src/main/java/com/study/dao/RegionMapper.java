package com.study.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.study.entity.Region;

public interface RegionMapper extends BaseMapper<Region> {
}
