package com.study.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.study.entity.Admin;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface AdminMapper extends BaseMapper<Admin> {


}
